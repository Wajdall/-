const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Connect to MongoDB
mongoose.connect("mongodb+srv://ClusterWeb2:zDE1xXVRtdkIBIBE@clusterweb.opntn.mongodb.net/?retryWrites=true&w=majority&appName=ClusterWeb", { useNewUrlParser: true, useUnifiedTopology: true });

const employeeSchema = new mongoose.Schema({ // البيانات اللي بدي ياها
    name: String,
    company: String,
    hoursPerDay: Number,
    hoursPerWeek: Number,
    salary: Number
});

const Employee = mongoose.model("Employee", employeeSchema); // النموذج (Model) الذي يمكننا استخدامه لإنشاء موظفين جدد أو جلب البيانات من قاعدة البيانات.

app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// Home Page
app.get("/", (req, res) => {
    res.render("index");
});

// Form Page (Add Employee)
app.get("/form", (req, res) => {
    res.render("form");
});

// Save Employee to Database
app.post("/add-employee", async (req, res) => {
    const { name, company, hoursPerDay, hoursPerWeek } = req.body;
    const salary = hoursPerDay * hoursPerWeek * 100;

    const newEmployee = new Employee({ name, company, hoursPerDay, hoursPerWeek, salary });
    await newEmployee.save();

    res.redirect("/employees");
});

// Employees List Page
app.get("/employees", async (req, res) => {
    const employees = await Employee.find();
    res.render("employees", { employees });
});

// Edit Employee Page
app.get("/edit/:id", async (req, res) => {
    const employee = await Employee.findById(req.params.id);
    res.render("edit", { employee });
});

// Update Employee
app.post("/update/:id", async (req, res) => {
    const { name, company, hoursPerDay, hoursPerWeek } = req.body;
    const salary = hoursPerDay * hoursPerWeek * 100;

    await Employee.findByIdAndUpdate(req.params.id, { name, company, hoursPerDay, hoursPerWeek, salary });

    res.redirect("/employees");
});

// Delete Employee
app.post("/delete/:id", async (req, res) => {
    await Employee.findByIdAndDelete(req.params.id);
    res.redirect("/employees");
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
